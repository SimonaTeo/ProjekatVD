function prekoParagrafaBoja(){
    var paragraf1=document.getElementById("paragraf");
    paragraf1.style.backgroundColor="white"
    paragraf1.style.border="solid";
}

