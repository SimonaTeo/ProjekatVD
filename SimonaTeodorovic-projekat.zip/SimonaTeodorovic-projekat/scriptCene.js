
function uvelicanaSlika(x) {
    x.style.height = "400px";
    x.style.width = "400px";
    x.style.border="solid";
}
  
function normalnaVelicinaSlike(x) {
    x.style.height = "230px";
    x.style.width = "230px";
    x.style.border="dotted";
}

function probaj(){
    var span=document.getElementById("prvispan").addEventListener("mouseover", spanPoruka);

    function spanPoruka() {
        alert ("Za više informacija o promenama izleta dodjite na našu adresu Trg Dositeja Obradovića 3 ");
    }

}
