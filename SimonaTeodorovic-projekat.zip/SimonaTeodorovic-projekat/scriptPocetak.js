
function make(){
    var p1=document.createElement("pre");
    var n = document.createTextNode("Uverite se i sami zašto smo najbolji!");
    p1.appendChild(n);
    var elem = document.getElementById("naslov1");
    elem.appendChild(p1);

    p1.style.color='blue';
  

      
}
