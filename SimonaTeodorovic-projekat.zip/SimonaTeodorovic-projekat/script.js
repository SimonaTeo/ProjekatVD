function inicijalizacija(){

    var unosEmaila=document.getElementById("email");
    unosEmaila.oninvalid=invalidEmail;
    unosEmaila.oninput=invalidEmail;

    var unosOdgovora=document.getElementById("odgovor");
    unosOdgovora.oninvalid=invalidOdgovor;
    unosOdgovora.oninput=invalidOdgovor;

    var unosBrojaTel=document.getElementById("phone");
    unosBrojaTel.oninvalid=invalidBr;
    unosBrojaTel.oninput=invalidBr;

    var unosIme = document.getElementById("ime");
	unosIme.oninvalid = invalidIme;
	unosIme.oninput = invalidIme;

	var unosPrezime = document.getElementById("prezime");
	unosPrezime.oninvalid = invalidPrezime;
	unosPrezime.oninput = invalidPrezime;

    var unosJMBG=document.getElementById("jmbg");
    unosJMBG.oninvalid=invalidJMBG;
    unosJMBG.oninput=invalidJMBG;

    var unosKomentara = document.getElementById("comment");
	unosKomentara.oninvalid = invalidKomentar;
	unosKomentara.oninput = invalidKomentar;
}

function invalidEmail(){
    this.setCustomValidity("");
    if(this.validity.valueMissing){
        this.setCustomValidity("Morate uneti email");
    }else if(this.validity.patternMismatch){
        this.setCustomValidity("Email nije ispravno unesen");
    }
}
function invalidOdgovor(){
    this.setCustomValidity("");
    if(this.validity.valueMissing){
        this.setCustomValidity("Morate odabrati jednu od ponudjenih stavki");
    }
}
function invalidJMBG(){
    this.setCustomValidity("");
    if(this.validity.valueMissing){
        this.setCustomValidity("Morate uneti JMBG");
    }
    else if(this.value.length!=13){
        this.setCustomValidity("JMBG mora imati 13 cifara")
    }
}
function invalidKomentar(){
    this.setCustomValidity("");
	if (this.validity.tooLong) {
		this.setCustomValidity("Komentar mora biti manji od 400 karaktera.");
	}
}
function provera(){

    var prvi=document.getElementById("box1");
    var drugi=document.getElementById("box2");
    var treci=document.getElementById("box3");
    var cetvrti=document.getElementById("box4");
    var peti=document.getElementById("box5");

    var brojac=0;

    if(prvi.checked)
        brojac+=1;
    if(drugi.checked)
        brojac+=1;
    if(treci.checked)
        brojac+=1;
    if(cetvrti.checked)
        brojac+=1;
    if(peti.checked)
        brojac+=1;
    
    if(brojac==0){
        alert("Morate odabrati barem jednu stavku zasto nas kontaktirate");
        return false;
    }
    return true;
    
}

function invalidBr(){
    this.setCustomValidity("");
    if(this.validaty.valueMissing){
        this.setCustomValidity("Morate uneti broj telefona");
    }else if(this.validaty.patternMismatch){
        this.setCustomValidity("Broj telefona nije unet ispravno");
    }
}

function invalidIme(){
    this.setCustomValidity("");
	if (this.validity.valueMissing) {
		this.setCustomValidity("Morate uneti ime");
	}
	if(this.value.charAt(0).toUpperCase() != this.value.charAt(0)) {
		this.setCustomValidity("Prvo slovo imena mora biti veliko");
	}
}

function invalidPrezime(){
    this.setCustomValidity("");
	if (this.validity.valueMissing) {
		this.setCustomValidity("Morate uneti prezime");
	}
	if(this.value.charAt(0).toUpperCase() != this.value.charAt(0)) {
		this.setCustomValidity("Prvo slovo prezimena mora biti veliko");
	}
}


