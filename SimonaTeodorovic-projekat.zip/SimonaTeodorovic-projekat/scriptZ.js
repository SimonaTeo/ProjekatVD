var prozor, prozorDodje, prozorOde, provera = true, prozordodjeode;
function ucitavanje() {
	prozor = document.getElementById("prozor");
	prozor.style.right = "-180px";
	prozordodjeode = setInterval(dodjeode, 2000);
}

function dodjeode() {
	if(provera) {
		prozorDodje = setInterval(dosao, 1);
	}
	if(!provera) {
		prozorOde = setInterval(otisao, 1);
	}
}

function dosao() {
	if(parseInt(prozor.style.right) != 0) {
		prozor.style.right = parseInt(prozor.style.right)+2+"px";
	}
	else  {
		clearInterval(prozorDodje);
		provera = false;
	}
}

function otisao() {
	if(parseInt(prozor.style.right) != -180) {
		prozor.style.right = parseInt(prozor.style.right)-2+"px";
	}
	else { 
		clearInterval(prozorOde);	
		provera = true;
	}
}
