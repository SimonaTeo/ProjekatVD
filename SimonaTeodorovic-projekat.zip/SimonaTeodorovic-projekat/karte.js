var glSlika;
var levaPozicija = 0;

function otvori(){
    sadrzaj=document.getElementById("sadrzaj");
    sadrzaj.style.position="absolute";
    sadrzaj.style.top="-600px";
    var s=setInterval(dole,1);



    glSlika = document.getElementById("slika"); 
	inicijalizacijaLinkova();
}
function dole(){
    if(parseInt(sadrzaj.style.top)!=150){
        sadrzaj.style.top=parseInt(sadrzaj.style.top)+2+"px"; 
    }
    else{
        clearInterval(s);
    }
}

function inicijalizacijaLinkova() {
	var links = document.getElementById("links"); 				  
	for (var i = 0; i < links.children.length; i++) { 												 
		var link = links.children[i]; 
		link.onclick = prikaziSliku; 
		var img = document.createElement("img"); 
		img.setAttribute("src", link.getAttribute("href")); 
		link.appendChild(img); 
	}
}

function resetujKl() {
	var links = document.getElementById("links"); 
	for (var i = 0; i < links.children.length; i++) { 
		var link = links.children[i]; 
		link.className = ""; 
	}
}

function prikaziSliku(event) {
	resetujKl(); 
	this.className = "selected";
	glSlika.setAttribute("src", this.getAttribute("href"));
	event.preventDefault();
	levaPozicija = 0;
	pozicija();
}

function levo() {
	levaPozicija -= 30; 
	pozicija(); 
}

function desno() {
	levaPozicija += 30; 
	pozicija();
}
function pozicija() {
	glSlika.style.left = levaPozicija + "px";
}

var trenutnaZanimljivost = 0;
var zanimljivostii = ["SmVkbm8gc2VkaXN0ZSB1IGVrb25vbXNrb2oga2xhc2kga29zdGEgb2tvIGRlc2V0IGhpbGphZGEgZG9sYXJhLCBkb2sgY2VuYSBzZWRpc3RhIHUgcHJ2b2osIGJpem5pcyBrbGFzaSBrcmVjZSBjYWsgaSBpem5hZCAyNTAgaGlsamFkYSBkb2xhcmEuIEFsaSBvdmUgY2lmcmUgbmUgY3VkZSwgamVyIHN2YWtha28gZGEgc2VkaXN0YSB1IGF2aW9udSBuaXN1IG9iaWNuYSBzZWRpc3RhLiBOYWltZSwgc3ZhIGF2aW9uc2thIHNlZGlzdGEgbW9yYWp1IGRhIGl6ZHJ6ZSB2ZWxpa2Ugc2lsZSwgYWxpIGRhIGJ1ZHUgdmVvbWEgbGFrYS4=",
				"QXZpb25za2kgcmV6ZXJ2b2FyaSBzZSBuYWxhemUgdSBrcmlsaW1hIGkgY2VudHJhbG5vbSBkZWx1IHRydXBhLCB0YWtvenZhbm9tIHN0b21ha3UgYXZpb25hLiBLYWtvIGplIGF2aW9uIHByZXZvem5vIHNyZWRzdHZvIGtvamUgcHJlbGF6aSB2ZWxpa3Uga2lsb21ldHJhenUsIG5lIGN1ZGkgc3RvIHN1IHJlemVydm9hcmkgemEgZ29yaXZvIHRvbGlrbyB2ZWxpa2kgZGEga3JveiBuamloIG1vemUgZGEgcHV6aSBjb3Zlay4gR2lnYW50c2tpIHJlemVydm9hcmkgc2UgcHVuZSBwcmUgc3Zha29nIGxldGEgaSBtb2d1IGRhIHNhZHJ6ZSB2ZWxpa2Uga29saWNpbmUgZ29yaXZhLg==",
				"QnJhY2EgUmFqdCBvc21pc2xpbGEgc3UgcHJ2aSBhdmlvbiBrb2ppIGplIHBvbGV0ZW8gMTkwMy4gZ29kaW5lLiBUYWRhIGplLCBwcmVjaXpuaWplLCBvZHJ6YW4gcHJ2aSBsZXQgb2JqZWt0YSB0ZXplZyBvZCB2YXpkdWhhLiBOamlob3YgYXZpb24sIFdyaWdodCBGbHllciwgbGV0ZW8gamUgb2tvIDEyMCBtZXRhcmEuIFJhZGkgcG9yZWRqZW5qYSAtIGRhbmFzbmppIEJvaW5nIDc4NyBtb3plIGRhIGxldGkgMTAwMDAga2lsb21ldGFyYSBzYSBzYW1vIGplZG5pbSBnYXNuaSByZXplcnZvYXJvbS4=",
				"UGlsb3RpIHNhIGtvbnRyb2xvcmltYSBsZXRhLCBkcnVnaW0gcGlsb3RpbWEgaSBzdmltYSB1a2xqdWNlbmltIG9zb2JhbWEgdSB2YXpkdXNub20gc2FvYnJhY2FqdSBrb25zdGFudG5vIGtvbXVuaWNpcmFqdS4gT3ZvIHNlIHByZSBzdmVnYSBkZXNhdmEgemJvZyBvcmdhbml6YWNpamUsIGFsaSBpIHpib2cgYmV6YmVkbm9zdGkgbGV0YS4gQWtvIHNlIHBpdGF0ZSBrb2ppIGplIHp2YW5pY25pIGplemlrIGtvamkgb25pIGtvcmlzdGUgLSB0byBqZSBlbmdsZXNraSBqZXppay4gVnJsbyBwb3B1bGFyYW4gaSBzaXJvbSBFdnJvcGUsIGEgbWF0ZXJuamkgYW5nbG9zYWtzb25za29nIGRlbGEgc3ZldGEgLSBlbmdsZXNraSBqZSB1c3BlbyBkYSBvc3ZvamkgaSBzdmV0LCBhbGkgaSB2YXpkdXNubyBwb2RydWNqZS4=",
				"RGFuYXMgc2UgcHJhdmUgYXZpb25pIGtvamkgc3UgdSBzdGFuanUgZGEgbGV0ZSBiZXogbW90b3JhIGkgdG8gc2Ugem92ZSBnbGFkZSByYXRpby4gTmFpbWUsIGF2aW9uaSBtb2d1IG5hIHN2YWtpaCBpemd1YmxqZW5paCAzMDAgbWV0YXJhIHZpc2luZSwgbGViZGVjaSBkYSBwcmVkanUgb2tvIDMga2lsb21ldGFyYSwgdGUgamUgYXZpb24gcHJldm96bm8gc3JlZHN0dm8ga29qZSBvZHJlZGplbiB2cmVtZW5za2kgcGVyaW9kIG1vemUgZGEgbGV0aSBiZXogdXBvdHJlYmUgbW90b3JhLCB1a29saWtvIGplIHRvIHBvdHJlYm5vLg==",
				"QW1lbGlhIEVhcmhhcnQgYmlsYSBqZSBwcnZhIHplbmEgcGlsb3Qga29qYSBqZSBwcmVsZXRlbGEgQWx0bGFuc2tpIG9rZWFuLiBaZW5lIGkgZGFsamUgbmlzdSBwb3RwdW5vIHJhdm5vcHJhdm5vIHphc3R1cGxqZW5lIHUgY2Vsb2ogYXZpbyBpbmR1c3RyaWppLCBhIG9uYSBqZSBwb3Rwb21vZ2xhIGRhIHNlIHRhZGEgdmlzZSB1a2xqdWNlIHUgbmp1LiBQb21vZ2xhIGplIG9zbml2YW5qZSBvcmdhbml6YWNpamUgOTkgIGtvamEgamUgYmlsYSBuYW1lbmplbmEgemVuYW1hIHBpbG90aW1hIGkgbmppaG92aW0gaW1wcmVzaXZuaW0gcG9zdGlnbnVjaW1hLg==",
			"SWFrbyBwdXRvdmFuamUgYXZpb25vbSB2aXNlIG5lIHByZWRzdGF2bGphIHRvbGlraSBwcmVzdGl6IGthbyDFoXRvIGplIHRvIGJpbyBzbHVjYWogdSByYW5pamltIHZyZW1lbmltYSAtIHByaXZhdG5pIGF2aW9uaSB0byBpIGRhbGplIGNpbmUsIHRlIHBvc3RvamkgdmVsaWtpIGJyb2ogbHVrc3V6bmloIGF2aW9uYS4gS2FvIHN0YXR1c25pIHNpbWJvbGksIHZybG8gZWZpa2FzbmkgaSBmdW5rY2lvbmFsbmksIHByaXZhdG5pIGF2aW9uaSBuYWpib2dhdGlqaWggbGp1ZGkgc3ZldGEgc3ZlIGNlc2NlIHBvZHNlY2FqdSBuYSBwcmF2ZSBsZXRlY2UgcGFsYXRlIGtvamUgdSBzdm9tIHNhc3RhdnUgaW1hanUgcG96bGFjZW5lIHRvYWxldGUsIGdhcmF6ZSB6YSBhdXRvbW9iaWxlIGkgcG8gbmVrb2xpa28gc3BhdmFjaWggc29iYSBuYWpsdWtzdXpuaWplZyB1cmVkamVuamEu"];

function drugaZanimljivost() {
	if (trenutnaZanimljivost >= zanimljivostii.length) {
		alert("Dosli ste do kraja. Pritiskom na dugme reset mozete ponovo citati zanimljivosti");
		return;
	}
	var kontejner = document.getElementById("zanimljivosti");
	kontejner.innerHTML = atob(zanimljivostii[trenutnaZanimljivost]);
	trenutnaZanimljivost++; 
}
function reset() {
	trenutnaZanimljivost = 0;
	var kontejner = document.getElementById("zanimljivosti");
	kontejner.innerHTML = "";
	console.log("Resetovan brojac");
}